/// Type of the animations for the mobile view.
enum AnimationType {
  /// Animates to the right.
  right,

  /// Animates to the left.
  left,
}
